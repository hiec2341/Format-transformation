# 音频格式转换器
一个纯前端实现的音频格式转换工具，支持 WAV/FLAC/MP3 格式互转，无需后端、无需下载 FFmpeg，纯浏览器本地处理。

## ✨ 功能特点
- 📤 支持文件点击选择/拖拽上传
- 🎛️ 支持 WAV/FLAC/MP3 格式互转
- 📊 实时显示转换进度
- 💾 转换完成后可直接下载文件
- 🔒 纯本地处理，文件不上传至任何服务器
- 📱 响应式设计，适配电脑/平板/手机

## 🚀 快速使用
### 本地运行
1. 克隆仓库：
   ```bash
   git clone https://github.com/你的GitHub用户名/audio-converter.git
   cd audio-converter